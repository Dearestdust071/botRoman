namespace WhatsAppService.Api.Services.PokeApi
{
public interface IPokeApiService{
        Task<string> TraerPokemon (string NombrePokemon);
}





}