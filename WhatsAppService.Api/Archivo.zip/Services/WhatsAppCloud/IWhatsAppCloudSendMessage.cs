namespace WhatsAppService.Api.Services.WhatsAppCloud
{

    public interface IWhatsAppCloudSendMessage{
        Task<string> EnviarMensaje(string token, object body);
    }







}