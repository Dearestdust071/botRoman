using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
namespace WhatsAppService.Api.Services.WhatsAppCloud
{

    public class WhatsAppCloudSendMessage : IWhatsAppCloudSendMessage
    {

        private readonly string endpoint = "https://graph.facebook.com/v20.0/142689948936579/messages";

        public async Task<string> EnviarMensaje(string token, object body)
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            string uri = $"{endpoint}";
            object message = body;
            string jsonContent = JsonSerializer.Serialize(message);
              var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(uri, content);
            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                return responseContent;
            }
            return string.Empty;

        }



    }



}