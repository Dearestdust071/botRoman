using WhatsAppService.Api.Models;
namespace WhatsAppService.Api.Util
{

    public interface IUtil
    {

        string GetUserText(MessageModel message);
        object TextMessage(string message, string number);
        string GetNumber(MessageModel message);
        string GetUserType(MessageModel message);
        object ImageMessage(string number, string link);
        object LocationMessage(string number);
        object ButtonMessage(string number);

    }



}