using WhatsAppService.Api.Models;

namespace WhatsAppService.Api.Util
{
    public class Util : IUtil
    {
        // public string GetUserText(MessageModel message)
        // {
        //     // plural?
        //     string tipo = message.Entry[0].Changes[0].Value.Messages[0].Type;
        //     if (tipo == "text")
        //     {
        //         string mensaje = message.Entry[0].Changes[0].Value.Messages[0].Text.Body;
        //         return mensaje;
        //     }
        //     else
        //     {
        //         return "Error";
        //     }

        // }


        public string GetUserText(MessageModel message)
        {
            var mensaje = message.Entry[0].Changes[0].Value.Messages[0];

            switch (mensaje.Type.ToUpper())
            {
                case "TEXT":
                    return mensaje.Text.Body;
                    break;

                case "INTERACTIVE":
                    string interactiveType = mensaje.Interactive.Type;
                    if (interactiveType.ToUpper() == "LIST_REPLY")
                    {
                        return mensaje.Interactive.List_Reply.Title;
                    }
                    else if (interactiveType.ToUpper() == "BUTTON_REPLY")
                    {
                        return mensaje.Interactive.Button_Reply.Title;
                    }
                    else
                    {
                        return string.Empty;
                    }
                    break;
                case "IMAGE":
                    return mensaje.Text.Body;
                case "LOCATION":
                    return mensaje.Text.Body.ToString();
                default:
                    return string.Empty;
            }

            return string.Empty;
        }

        public string GetUserType(MessageModel message)
        {
            return message.Entry[0].Changes[0].Value.Messages[0].Type.ToUpper();
        }

        public string GetNumber(MessageModel message)
        {
            // plural? si
            string numero = message.Entry[0].Changes[0].Value.Messages[0].From;
            return numero;
        }

        public object TextMessage(string message, string number)
        {
            return new
            {
                messaging_product = "whatsapp",
                recipient_type = "individual",
                to = number,
                type = "text",
                text = new { preview_url = true, body = message },
            };
        }

        public object ImageMessage(string number, string link)
        {
            return new
            {
                messaging_product = "whatsapp",
                recipient_type = "individual",
                to = number,
                type = "image",
                image = new { link = link },
            };
        }

        public object LocationMessage(string number)
        {
            return new
            {
                messaging_product = "whatsapp",
                recipient_type = "individual",
                to = number,
                type = "location",
                location = new
                {
                    latitude = "19.432608",
                    longitude = "-99.133209",
                    name = "Palacio de Bellas Artes",
                    address = "Docker",
                },
            };
        }

        
        public object ButtonMessage(string number)
        {
            return new
            {
                messaging_product = "whatsapp",
                recipient_type = "individual",
                to = number,
                
                header = new
                {
                    type = "text", 
                    text = "Menú Principal"
                },
                body = new
                {
                    text = "Selecciona una opción"
                },
                footer = new
                {
                    text = "Gracias por usar nuestro servicio"
                },
                action = new
                {
                    button = "Seleccionar",
                    sections = new[]
                    {
                new
                {
                    title = "Opciones Generales",
                    rows = new[]
                    {
                        new
                        {
                            id = "Opcion_1",
                            title = "Consultar Saldo",
                            description = "Saldo disponible"
                        },
                        new
                        {
                            id = "Opcion_2",
                            title = "Historial",
                            description = "Últimas transacciones"
                        }
                    }
                },
                new
                {
                    title = "Servicios Adicionales",
                    rows = new[]
                    {
                        new
                        {
                            id = "Opcion_3",
                            title = "Activar notificaciones",
                            description = "Recibir notificaciones"
                        },
                        new
                        {
                            id = "Opcion_4",
                            title = "Cambiar contraseña",
                            description = "Actualizar tu contraseña"
                        }
                    }
                }
            }
                }
            };
        }



        // public object InteractiveMessage (string number, string prueba)
        // {
        //     return new
        //     {
        //         messaging_product = "whatsapp",
        //         recipient_type = "individual",
        //         to = number,
        //         type = "location",
        //         location = new
        //         {
        //             latitude = "19.432608",
        //             longitude = "-99.133209",
        //             name = "Palacio de Bellas Artes",
        //             address = prueba,
        //         },
        //     };
        // }
    }
}
