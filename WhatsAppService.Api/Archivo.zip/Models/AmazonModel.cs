namespace WhatsAppService.Api.Models
{

    public partial class AmazonModel
    {
        public string query { get; set; }
        public string page { get; set; }
        public string country { get; set; }
        public string sort_by { get; set; }
        public string product_condition { get; set; }
    }
}
