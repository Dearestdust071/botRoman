namespace WhatsAppService.Api.Models{
    public class BodyModel{
        public string Pokemon {get;set;}
        
    }




}