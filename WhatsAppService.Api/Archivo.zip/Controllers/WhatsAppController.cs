using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WhatsAppService.Api.Models;
// using WhatsAppService.Api.Services.PokeApi;
using WhatsAppService.Api.Services.AmazonService;
using WhatsAppService.Api.Services.WhatsAppCloud;
using WhatsAppService.Api.Util;

namespace WhatsAppService.Api.Controllers
{
    //Esto sirve para acceder al archivo "WhatsappController"
    [Route("api/whatsapp")]
    [ApiController]
    public class WhatsappController : Controller
    {
        // private readonly IPokeApiService _pokeApiService;
        private readonly IAmazonService _amazonService;
        private readonly IUtil _util;
        private readonly IWhatsAppCloudSendMessage _whatsAppCloudSendMessage;
        //instancia del servicio


        //Consultor
        // [HttpPost("Pokemon")]
        public WhatsappController(IAmazonService amazonService, IUtil util, IWhatsAppCloudSendMessage whatsAppCloudSendMessage)
        {
            // _pokeApiService = pokeApiService;
            // Inyectamos el servicio cosa
            _amazonService = amazonService;
            _util = util;
            _whatsAppCloudSendMessage = whatsAppCloudSendMessage;
        }

        // Esta ruta es para configurar mi webhook
        [HttpGet("webhook")]
        public IActionResult VerifyToken()
        {
            string AccesToken = "hola";
            string token = Request.Query["hub.verify_token"].ToString();
            string challenge = Request.Query["hub.challenge"].ToString();

            if (token == AccesToken && token != null && challenge != null)
            {
                return Ok(challenge);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPost("webhook")]
        public async Task<IActionResult> RecibirMensaje([FromBody] MessageModel message)
        {
            string link_gato = "https://imgs.search.brave.com/rXPaVhOsIXrMxoh9pBo7aO0008VflG54tLKRquRYFLs/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWFn/ZW5lc2Jvbml0YXMu/Ym9zcXVlZGVmYW50/YXNpYXMuY29tL3dw/LWNvbnRlbnQvdXBs/b2Fkcy8yMDE1LzA4/L2dhdG8tZ3JhY2lv/c28uanBn";
            string token = "EAAHMkNepFcsBOys3ZBr0aJCXRZA4rIJDIsknbqdUwJTZBCQf2vGLrLHJ5keUX52udLGWXPcNPv4oz4ZAGGw6rq6uJLjwjxsVaqpJv4RdQnhaBv7bLx8VMeOBbnZAoFrNwSDdl5alD6I3ZBfb3GqBG5Cuui74FTCLPymKW0SnlQJiRyZBr3ToNkWgJMY8teSNTRXVdE9stL39wpHiiAArudWbZB3rIOoZD";
            string Numero = "524151675040";
            string Mensaje = _util.GetUserText(message);
            switch (Mensaje)
            {
                case "image":
                    return Ok(
                        await _whatsAppCloudSendMessage.EnviarMensaje(
                            token,
                            _util.ImageMessage(Numero, link_gato)
                        ));
                case "text":
                    return Ok(
                        await _whatsAppCloudSendMessage.EnviarMensaje(
                            token,
                            _util.TextMessage("Texto random va!", Numero)
                        )
                    );
                case "location":
                    return Ok(
                        await _whatsAppCloudSendMessage.EnviarMensaje(
                            token,
                            _util.LocationMessage(Numero)
                        )
                    );
                case "button":
                    return Ok(
                        await _whatsAppCloudSendMessage.EnviarMensaje(
                                token,
                                _util.ButtonMessage(Numero)
                            )
                        );
                default:
                    return Ok(
                        _util.TextMessage("No tenemos soporte para este tipo de mensajes", Numero)
                    );
            }



            // if(GetTypeText(message)){
            //     return Ok(GetUserText(message));
            // }
            // else{
            //     return BadRequest();
            // }
            //    string Mensaje = GetUserText(message);
            //    return Ok(Mensaje);
        }

        // [HttpPost("Pokemon")]
        // public async Task<IActionResult> GetPokemon([FromBody] BodyModel body)
        // {
        //     try
        //     {
        //         var response = await _pokeApiService.TraerPokemon(body.Pokemon);
        //         return Content(response, "application/json");
        //     }
        //     catch (HttpRequestException ex)
        //     {

        //         return BadRequest(ex.Message);
        //     }
        // }





        [HttpPost("Amazon")]
        public async Task<IActionResult> GetProducto([FromBody] AmazonModel body)
        {
            try
            {
                var response = await _amazonService.RevisarProductos(
                    body.query,
                    body.page,
                    body.country,
                    body.sort_by,
                    body.product_condition
                );
                return Content(response, "application/json");
            }
            catch (HttpRequestException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //Creo una lista para guardar ahi los datos del POST
        private static List<string> mensajes = new List<string>();
        // Sirve para acceder a la función que se encuentra en la ruta
        // [HttpGet("GET/{msg}")]
        // public IActionResult GET(string msg)
        // {
        //     return Ok(
        //         new{
        //             msj = msg
        //         }
        //     );
        // }

        // //  [HttpPost]

        // //  public IActionResult POST([FromBody] SumaModel body )
        // // {
        // //     double resultado = 0;
        // //     if(body.Operacion == "Suma"){
        // //          resultado = body.Num1 + body.Num2;
        // //     } else if (body.Operacion == "Resta")
        // //     {
        // //         resultado = body.Num1 - body.Num2;
        // //     } else if (body.Operacion == "Multiplicacion")
        // //     {
        // //         resultado = body.Num1 * body.Num2;
        // //     } else if (body.Operacion == "Division")
        // //     {
        // //         resultado = body.Num1 / body.Num2;
        // //     }
        // //     return Ok(
        // //         new {
        // //             msj = resultado
        // //             }
        // //             );
        // // }
    }
}
